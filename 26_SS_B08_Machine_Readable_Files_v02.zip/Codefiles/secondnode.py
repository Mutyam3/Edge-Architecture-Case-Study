# secondnode.py
import time
import os
import sys
import struct
import platform

try:
    import board
    import busio
    import digitalio
    import can
    from adafruit_ads1x15.ads1115 import ADS1115
    from adafruit_ads1x15.analog_in import AnalogIn
except ImportError:
    print("Execution failure: Missing core hardware link libraries on target node.")
    sys.exit(1)


SOFTWARE_VERSION = platform.release()[:7]
CAN_INTERFACE = "can0"

JOY_CENTER = 13350
JOY_DEADZONE = 3000

try:
    i2c = busio.I2C(board.SCL, board.SDA)
    ads = ADS1115(i2c)
    
    joy2_x_adc = AnalogIn(ads, 0)
    joy2_y_adc = AnalogIn(ads, 1)
    
    joy2_sw = digitalio.DigitalInOut(board.D22)  
    joy2_sw.direction = digitalio.Direction.INPUT
    joy2_sw.pull = digitalio.Pull.UP

    extra_sw = digitalio.DigitalInOut(board.D23) 
    extra_sw.direction = digitalio.Direction.INPUT
    extra_sw.pull = digitalio.Pull.UP
    print("Slave Node Hardware components mapped safely.")
except Exception as hardware_err:
    print(f"I2C Peripheral or GPIO initialization crashed: {hardware_err}")
    sys.exit(1)

try:
    import psutil
    psutil.cpu_percent()
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

try:
    bus = can.interface.Bus(channel=CAN_INTERFACE, interface='socketcan')
    print(f"SocketCAN interface mapping complete on target protocol: {CAN_INTERFACE}")
except Exception as can_err:
    print(f"Link connection initialization failure over SocketCAN setup: {can_err}")
    sys.exit(1)


def get_system_stats():
    if not PSUTIL_AVAILABLE:
        return {
            "CPU": "0%", "RAM": "0%", "Memory": "0%", "Uptime": "0 Min",
            "Software Version/ buildID": SOFTWARE_VERSION, "Connection Status": "Active",
            "Temperature": "N/A", "Packet error count": "0"
        }
    try:
        cpu = f"{psutil.cpu_percent(interval=None)}%"
        ram = f"{psutil.virtual_memory().percent}%"
        disk = f"{psutil.disk_usage('/').percent}%"
        uptime_mins = int((time.time() - psutil.boot_time()) // 60)
        
        gateways = psutil.net_if_stats()
        status = "Active" if (CAN_INTERFACE in gateways and gateways[CAN_INTERFACE].isup) else "Faulty"
        
        # Real Core Temperature Reading
        try:
            with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
                temp_raw = int(f.read().strip())
                temp_str = f"{round(temp_raw / 1000.0, 1)}C"
        except Exception:
            temp_str = "N/A"

        # Real Hardware Interface Metric Calculation
        try:
            io_counters = psutil.net_io_counters(pernic=True)
            if CAN_INTERFACE in io_counters:
                net_stats = io_counters[CAN_INTERFACE]
                total_errors = net_stats.errin + net_stats.errout + net_stats.dropin + net_stats.dropout
                pk_errs = str(total_errors)
            else:
                pk_errs = "0"
        except Exception:
            pk_errs = "0"
            
    except Exception:
        cpu, ram, disk, uptime_mins, status, temp_str, pk_errs = "Err", "Err", "Err", 0, "Error", "N/A", "0"

    return {
        "CPU": cpu,
        "RAM": ram,
        "Memory": disk,
        "Uptime": f"{uptime_mins} Min",
        "Software Version/ buildID": SOFTWARE_VERSION,
        "Connection Status": status,
        "Temperature": temp_str,
        "Packet error count": pk_errs
    }


last_input_tx = 0.0
last_telemetry_tx = 0.0

print("Slave Node operational controller active. Broadcasting frames...")

try:
    while True:
        current_time = time.time()

        # 1. TRANSMIT HIGH-SPEED JOYSTICK MOVEMENT PACKETS (Every 50ms)
        if current_time - last_input_tx >= 0.05:
            last_input_tx = current_time
            
            try:
                x_val = joy2_x_adc.value
                y_val = joy2_y_adc.value
                
                p2_dx, p2_dy = 0, 0
                if y_val > JOY_CENTER + JOY_DEADZONE:   p2_dx = 255
                elif y_val < JOY_CENTER - JOY_DEADZONE: p2_dx = 1  
                if x_val > JOY_CENTER + JOY_DEADZONE:   p2_dy = 1
                elif x_val < JOY_CENTER - JOY_DEADZONE: p2_dy = 255

                btn1_pressed = not joy2_sw.value
                btn2_pressed = not extra_sw.value
                
                # Below definition prevents overlapping dual press flags
                lobby_ready_flag = 1 if (btn1_pressed and btn2_pressed) else 0
                single_btn_flag = 1 if ((btn1_pressed or btn2_pressed) and not lobby_ready_flag) else 0
                
                status_byte = (lobby_ready_flag << 0) | (single_btn_flag << 1)

                input_payload = struct.pack('BBB', p2_dx, p2_dy, status_byte)
                msg = can.Message(arbitration_id=0x100, data=input_payload, is_extended_id=False)
                bus.send(msg)
            except Exception as e:
                print(f"CAN Frame Input TX Exception (0x100): {e}")

        # 2. TRANSMIT BOARD TELEMETRY METRICS PACKETS (Every 3 Seconds)
        if current_time - last_telemetry_tx >= 3.0:
            last_telemetry_tx = current_time
            sys_metrics = get_system_stats()
            
            metric_mappings = [
                (1, sys_metrics["CPU"]),
                (2, sys_metrics["RAM"]),
                (3, sys_metrics["Memory"]),
                (4, sys_metrics["Uptime"]),
                (5, sys_metrics["Software Version/ buildID"]),
                (6, sys_metrics["Connection Status"]),
                (7, sys_metrics["Temperature"]),
                (8, sys_metrics["Packet error count"])
            ]
            
            for param_id, text_value in metric_mappings:
                encoded_str = text_value[:7].encode('utf-8')  
                telemetry_payload = struct.pack('B', param_id) + encoded_str
                
                try:
                    msg = can.Message(arbitration_id=0x200, data=telemetry_payload, is_extended_id=False)
                    bus.send(msg)
                    time.sleep(0.015)  # Extended mitigation gap preventing TX hardware queue bottlenecks
                except Exception as e:
                    print(f"CAN Frame Telemetry TX Exception (0x200): {e}")

        time.sleep(0.001)

except KeyboardInterrupt:
    print("Slave node shutting down gracefully...")
finally:
    bus.shutdown()
    print("CAN bus closed.")