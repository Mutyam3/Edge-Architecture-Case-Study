# board_stats.py
import platform
import time
import psutil

# Cache platform release info at import time since it never changes at runtime
_SW_VERSION = platform.release()[:7]

# Baseline warm-up sample window initialization
psutil.cpu_percent()


def get_board_stats(comm_latency_ms=0.0):
    # 1. CPU Usage
    cpu_usage = f"{psutil.cpu_percent(interval=None)}%"

    # 2. RAM Usage
    ram = psutil.virtual_memory()
    ram_usage = f"{ram.percent}%"

    # 3. System Uptime
    uptime_seconds = time.time() - psutil.boot_time()
    uptime_mins = int(uptime_seconds // 60)
    uptime_str = f"{uptime_mins} Min"

    # 4. Storage Memory Allocation
    disk = psutil.disk_usage('/')
    disk_usage = f"{disk.percent}%"

    # 5. Software version string
    software_version = _SW_VERSION

    # 6. SocketCAN hardware link state status
    target_interface = "can0"
    try:
        gateways = psutil.net_if_stats()
        if "can0" in gateways and gateways["can0"].isup:
            connection_status = "Connected"
            target_interface = "can0"
        elif "vcan0" in gateways and gateways["vcan0"].isup:
            connection_status = "Virtual UP"
            target_interface = "vcan0"
        else:
            connection_status = "Disconnected"
    except Exception:
        connection_status = "Error"

    # 7. Core Temperature
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", "r") as f:
            temp_raw = int(f.read().strip())
            temperature = f"{round(temp_raw / 1000.0, 1)}C"
    except Exception:
        temperature = "N/A"

    # 8. Packet Error Count
    try:
        io_counters = psutil.net_io_counters(pernic=True)
        if target_interface in io_counters:
            net_stats = io_counters[target_interface]
            total_errors = net_stats.errin + net_stats.errout + net_stats.dropin + net_stats.dropout
            packet_errors = str(total_errors)
        else:
            packet_errors = "0"
    except Exception:
        packet_errors = "0"

    # 9. Communication Latency
    comm_latency = f"{round(comm_latency_ms, 1)}ms"

    return {
        "CPU": cpu_usage,
        "RAM": ram_usage,
        "Uptime": uptime_str,
        "Memory": disk_usage,
        "Software Version/ buildID": software_version,
        "Connection Status": connection_status,
        "Temperature": temperature,
        "Packet error count": packet_errors,
        "Communication latency": comm_latency
    }