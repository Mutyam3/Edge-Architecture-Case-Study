import pygame
import sys
import random
import time
import struct
import can
import board_stats
import session_manager
import export_manager

# HARDWARE IMPORTS
try:
    import board
    import busio
    import digitalio
    from adafruit_ads1x15.ads1115 import ADS1115
    from adafruit_ads1x15.analog_in import AnalogIn
    HARDWARE_LIBS_AVAILABLE = True
except ImportError:
    HARDWARE_LIBS_AVAILABLE = False

# SYSTEM INITIALIZATION
pygame.init()

WIDTH = 480
HEIGHT = 320
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("2P Pac-Man via Hardware & CAN")

# Track only structural framework events
pygame.event.set_allowed([pygame.QUIT, pygame.JOYBUTTONDOWN])

font = pygame.font.Font(None, 16)        
table_font = pygame.font.Font(None, 13)  
clock = pygame.time.Clock()

session_manager.register_cache_invalidation_callback(lambda: globals().update(gaming_data_cache=None))

# INITIALIZE ADS1115 & HARDWARE SWITCHES (LOCAL PLAYER 1)
CENTER = 13350
DEADZONE = 3000
ads_available = False
joy1_x_adc = None
joy1_y_adc = None
joy1_sw = None

if HARDWARE_LIBS_AVAILABLE:
    try:
        i2c = busio.I2C(board.SCL, board.SDA)
        ads = ADS1115(i2c)
        joy1_x_adc = AnalogIn(ads, 1)
        joy1_y_adc = AnalogIn(ads, 0)
        
        # Hardware push-button mapping for P1
        joy1_sw = digitalio.DigitalInOut(board.D22)
        joy1_sw.direction = digitalio.Direction.INPUT
        joy1_sw.pull = digitalio.Pull.UP
        
        ads_available = True
        print("Local ADS1115 Hardware Joystick and GPIO Button initialized.")
    except Exception as e:
        print(f"ADS1115 Hardware configuration failed: {e}")

# INITIALIZE CAN BUS (REMOTE PLAYER 2)
try:
    can_bus = can.interface.Bus(channel='can0', interface='socketcan')
    print("Primary Node CAN Bus listener initialized.")
except Exception as e:
    print(f"CAN Bus initialization failed: {e}.")
    can_bus = None

# GLOBAL STATE VARIABLES
current_state = "MAIN_MENU"
selected_option = 0

player1_name = ""
player2_name = ""
p1_done = False
p2_done = False

export_status_msg = ""
export_status_color = (200, 200, 200)

p2_joined_via_can = False
lobby_start_time = None
slave_node_telemetry = {}  

# Telemetry Latency Tracking
p2_last_0x100_time = None
p2_rolling_latency_ms = 0.0

def get_p2_stats():
    """Returns P2 remote telemetry with safe defaults when fields are missing."""
    defaults = {
        "CPU": "0%", "RAM": "0%", "Uptime": "0 Min", "Memory": "0%",
        "Software Version/ buildID": "Offline", "Connection Status": "Offline",
        "Temperature": "Offline", "Packet error count": "Offline",
        "Communication latency": "Offline"
    }
    return {k: slave_node_telemetry.get(k, v) for k, v in defaults.items()}

# ARCADE GRID SELECTION LAYOUT
CHAR_GRID = [
    ['A', 'B', 'C', 'D', 'E', 'F', 'G'],
    ['H', 'I', 'J', 'K', 'L', 'M', 'N'],
    ['O', 'P', 'Q', 'R', 'S', 'T', 'U'],
    ['V', 'W', 'X', 'Y', 'Z', ' ', '<'],
    ['DONE', 'DONE', 'DONE', 'DONE', 'DONE', 'DONE', 'DONE']
]

p1_grid_pos = [0, 0]
p2_grid_pos = [0, 0]

p1_nav_cooldown = 0
p2_nav_cooldown = 0
p1_btn_cooldown = 0  # Separate cooldown to prevent joystick movement lockout
p1_move_cooldown = 0
p2_move_cooldown = 0
COOLDOWN_FRAMES = 3  
MOVE_COOLDOWN_FRAMES = 4 

# GAMEPLAY LOGIC & MAZE CONSTANTS
TILE = 16
MAZE_Y_OFFSET = 45
# Dynamically center the screen canvas
MAZE_X_OFFSET = (WIDTH - (20 * TILE)) // 2 

player1_x, player1_y = 1, 1
player2_x, player2_y = 18, 1
score_p1, score_p2 = 0, 0
shared_lives = 3 

frightened_timer = 0
FRIGHTENED_DURATION = 50  

ghosts = [
    {"pos": [9, 5], "color": (255, 0, 0), "start_pos": [9, 5], "prev_pos": None},      
    {"pos": [10, 5], "color": (255, 182, 193), "start_pos": [10, 5], "prev_pos": None}   
]
ghost_timer = 0
GHOST_MOVES = ((0, 1), (0, -1), (1, 0), (-1, 0))

maze_raw = [
    "####################",
    "#O................O#",
    "#.####..####..####.#",
    "#..................#",
    "#.####..####..####.#",
    "#.......O..O.......#",
    "#.####..####..####.#",
    "#..................#",
    "#.####..####..####.#",
    "#O................O#",
    "####################",
]

maze = []
MAZE_ROWS = 0
MAZE_COLS = 0
total_dots = 0  

def init_maze():
    global maze, MAZE_ROWS, MAZE_COLS, total_dots
    maze = [list(row) for row in maze_raw]
    MAZE_ROWS = len(maze)
    MAZE_COLS = len(maze[0])
    total_dots = sum(row.count(".") + row.count("O") for row in maze)

init_maze()

# OPTIMIZATION: PRE-RENDERING SURFACE CACHES
maze_surface = pygame.Surface((WIDTH, HEIGHT))
maze_surface.fill((0, 0, 0))
for row_idx, row in enumerate(maze):
    for col_idx, cell in enumerate(row):
        if cell == "#":
            pygame.draw.rect(maze_surface, (0, 0, 255), (col_idx * TILE + MAZE_X_OFFSET, row_idx * TILE + MAZE_Y_OFFSET, TILE, TILE))
maze_surface = maze_surface.convert()

dot_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)

def rebuild_dot_surface():
    dot_surface.fill((0, 0, 0, 0))
    for row_idx, row in enumerate(maze):
        for col_idx, cell in enumerate(row):
            cx = col_idx * TILE + TILE // 2 + MAZE_X_OFFSET
            cy = row_idx * TILE + TILE // 2 + MAZE_Y_OFFSET
            if cell == ".":
                pygame.draw.circle(dot_surface, (255, 255, 255), (cx, cy), 2)
            elif cell == "O":
                pygame.draw.circle(dot_surface, (255, 184, 174), (cx, cy), 5)

rebuild_dot_surface()

title_surface = font.render("2P PACMAN VIA CAN", True, (255, 255, 255))
title_x = (WIDTH // 2) - (title_surface.get_width() // 2)

lobby_title_surf = font.render("GAME LOBBY", True, (255, 255, 255))
lobby_title_x = (WIDTH // 2) - (lobby_title_surf.get_width() // 2)
lobby_info_surf = table_font.render("Hardware synchronization link...", True, (150, 150, 150))
lobby_info_x = (WIDTH // 2) - (lobby_info_surf.get_width() // 2)
lobby_prompt_surf = table_font.render("Press Both Joystick SW Buttons on P2", True, (180, 180, 180))
lobby_prompt_x = (WIDTH // 2) - (lobby_prompt_surf.get_width() // 2)
lobby_ready_surf = table_font.render("Ready! Preparing operational map session...", True, (255, 255, 0))
lobby_ready_x = (WIDTH // 2) - (lobby_ready_surf.get_width() // 2)

lobby_p2_inactive_surf = font.render("PLAYER TWO: INACTIVE", True, (240, 140, 20))
lobby_p2_active_surf = font.render("PLAYER TWO ACTIVE", True, (0, 255, 0))

options = ["Start Game", "Gaming Data", "Board Stats", "Export Data", "Quit"]
menu_cache = []
start_y, spacing = 80, 40
for index, option_text in enumerate(options):
    current_y = start_y + (index * spacing)
    surf_normal = font.render(option_text, True, (150, 150, 150))
    x_normal = (WIDTH // 2) - (surf_normal.get_width() // 2)
    surf_selected = font.render(f"> {option_text} <", True, (255, 255, 0))
    x_selected = (WIDTH // 2) - (surf_selected.get_width() // 2)
    menu_cache.append((surf_normal, x_normal, surf_selected, x_selected, current_y))

gaming_title_surf = font.render("GAMING DATA", True, (255, 255, 255))
gaming_title_x = (WIDTH // 2) - (gaming_title_surf.get_width() // 2)

board_title_surf = font.render("BOARD STATS", True, (255, 255, 255))
board_title_x = (WIDTH // 2) - (board_title_surf.get_width() // 2)

export_title_surf = font.render("EXPORT DATA", True, (255, 255, 255))
export_title_x = (WIDTH // 2) - (export_title_surf.get_width() // 2)

instruction_surface = font.render("Press Joystick SW Button to Export Data", True, (200, 200, 200))
instruction_x = (WIDTH // 2) - (instruction_surface.get_width() // 2)

# Board Stats visual table parameters
table_w = 460
table_x = (WIDTH - table_w) // 2
table_y, row_h = 35, 24
col1_w, col2_w = 220, 110
col3_w = table_w - col1_w - col2_w

name_title_surf = font.render("ENTER PLAYER NAMES", True, (255, 255, 255))
name_title_x = (WIDTH // 2) - (name_title_surf.get_width() // 2)

cached_grid_surfaces = {}
for r_idx, row in enumerate(CHAR_GRID):
    for c_idx, char in enumerate(row):
        display_str = char if char != ' ' else "SPACE"
        cached_grid_surfaces[(r_idx, c_idx)] = table_font.render(display_str, True, (255, 255, 255))

gaming_data_cache = None
hud_surface = None
board_stats_surface_cache = None
board_stats_frame_counter = 0

def update_score_surfaces():
    global hud_surface
    hud_surface = pygame.Surface((WIDTH, MAZE_Y_OFFSET))
    hud_surface.fill((0, 0, 0))
    p1_surf = table_font.render(f"P1: {score_p1}", True, (255, 255, 0))
    p2_surf = table_font.render(f"P2: {score_p2}", True, (0, 255, 0))
    lives_surf = table_font.render(f"Lives: {shared_lives}", True, (255, 255, 255))
    hud_surface.blit(p1_surf, (MAZE_X_OFFSET + 10, 15))
    hud_surface.blit(p2_surf, (MAZE_X_OFFSET + 120, 15))
    hud_surface.blit(lives_surf, (MAZE_X_OFFSET + 240, 15))

update_score_surfaces()

def reset_positions():
    global player1_x, player1_y, player2_x, player2_y
    player1_x, player1_y = 1, 1
    player2_x, player2_y = 18, 1
    for ghost in ghosts:
        ghost["pos"] = list(ghost["start_pos"])
        ghost["prev_pos"] = None

def capture_real_input_latency():
    """local I2C bus hardware polling speed."""
    if not ads_available:
        return 1.5  # if hardware is missing
    try:
        t_start = time.perf_counter()
        _ = joy1_x_adc.value
        _ = joy1_y_adc.value
        t_end = time.perf_counter()
        return (t_end - t_start) * 1000.0
    except Exception:
        return 2.0

def execute_p1_button_action():
    global current_state, selected_option, player1_name, player2_name, p1_done, p2_done
    global shared_lives, score_p1, score_p2, frightened_timer, p2_joined_via_can, lobby_start_time
    global export_status_msg, export_status_color, gaming_data_cache

    if current_state in ("GAMING_DATA", "BOARD_STATS"):
        current_state = "MAIN_MENU"
        return

    if current_state == "EXPORT_DATA":
        if export_status_msg != "":  
            current_state = "MAIN_MENU"
            export_status_msg = ""
            return
        else:
            p1_active_stats = board_stats.get_board_stats(comm_latency_ms=p2_rolling_latency_ms)
            p2_active_stats = get_p2_stats()
            
            combined_stats = {
                "P1_Local": p1_active_stats,
                "P2_Remote": p2_active_stats
            }

            success, msg = export_manager.export_to_usb(combined_stats)
            export_status_msg = msg
            export_status_color = (0, 255, 0) if success else (255, 0, 0)
            return

    if current_state == "MAIN_MENU":
        if selected_option == 0:
            player1_name, player2_name = "", ""
            p1_done, p2_done = False, False
            p1_grid_pos[0], p1_grid_pos[1] = 0, 0
            p2_grid_pos[0], p2_grid_pos[1] = 0, 0
            shared_lives = 3
            score_p1, score_p2 = 0, 0
            frightened_timer = 0  
            p2_joined_via_can = False
            lobby_start_time = None
            init_maze()  
            reset_positions()
            rebuild_dot_surface()
            update_score_surfaces()
            current_state = "NAME_INPUT"
        elif selected_option == 1:  # Gaming Data Screen
            
            # 1. Calculate live properties
            real_input = capture_real_input_latency()
            real_transport = p2_rolling_latency_ms if 'p2_rolling_latency_ms' in globals() else 0.0

            # 2. Inject real values directly into file profile memory 
            current_data = session_manager.load_gaming_data()
            current_data["input_latency"] = round(real_input, 2)
            current_data["transport_delay"] = round(real_transport, 2)
            session_manager.save_gaming_data(current_data)

            # 3. Invalidate cache and transition UI view state
            gaming_data_cache = None  
            current_state = "GAMING_DATA"

        elif selected_option == 2: current_state = "BOARD_STATS"
        elif selected_option == 3:
            current_state = "EXPORT_DATA"
            export_status_msg, export_status_color = "", (200, 200, 200)
        elif selected_option == 4:
            pygame.quit()
            sys.exit()

    elif current_state == "NAME_INPUT" and not p1_done:
        p1_char = CHAR_GRID[p1_grid_pos[0]][p1_grid_pos[1]]
        if p1_char == 'DONE':
            p1_done = True
            if not player1_name: player1_name = "P1"
            if not player2_name: player2_name = "P2"
            if p2_done:
                current_state = "LOBBY_CHECK"
        elif p1_char == '<':
            if player1_name:
                player1_name = player1_name[:-1]
        elif len(player1_name) < 8:
            player1_name += p1_char
            
def poll_local_joystick_p1():
    global player1_x, player1_y, p1_grid_pos, p1_nav_cooldown, p1_btn_cooldown, p1_move_cooldown, selected_option
    if not ads_available:
        return

    try:
        x_val = joy1_x_adc.value
        y_val = joy1_y_adc.value
        
        dx, dy = 0, 0
        if x_val > CENTER + DEADZONE:   dx = -1
        elif x_val < CENTER - DEADZONE: dx = 1
        if y_val > CENTER + DEADZONE:   dy = 1
        elif y_val < CENTER - DEADZONE: dy = -1

        if current_state == "MAIN_MENU" and p1_nav_cooldown == 0:
            if dy != 0:
                selected_option = (selected_option + dy) % len(options)
                p1_nav_cooldown = COOLDOWN_FRAMES + 1 
        
        elif current_state == "NAME_INPUT" and not p1_done and p1_nav_cooldown == 0:
            if dx != 0 or dy != 0:
                p1_grid_pos[0] = (p1_grid_pos[0] + dy) % len(CHAR_GRID)
                p1_grid_pos[1] = (p1_grid_pos[1] + dx) % len(CHAR_GRID[0])
                p1_nav_cooldown = COOLDOWN_FRAMES

        elif current_state == "PLAYING" and p1_move_cooldown == 0:
            moved = False
            if dx == -1 and player1_x > 0 and maze[player1_y][player1_x - 1] != "#":  
                player1_x -= 1; moved = True
            elif dx == 1 and player1_x < MAZE_COLS - 1 and maze[player1_y][player1_x + 1] != "#": 
                player1_x += 1; moved = True
            elif dy == -1 and player1_y > 0 and maze[player1_y - 1][player1_x] != "#":  
                player1_y -= 1; moved = True
            elif dy == 1 and player1_y < MAZE_ROWS - 1 and maze[player1_y + 1][player1_x] != "#": 
                player1_y += 1; moved = True
            if moved:
                p1_move_cooldown = MOVE_COOLDOWN_FRAMES
            
        # Using dedicated p1_btn_cooldown here so directional stick tracking doesn't block clicks
        if p1_btn_cooldown == 0 and not joy1_sw.value:
            execute_p1_button_action()
            p1_btn_cooldown = COOLDOWN_FRAMES + 4

    except Exception as hardware_err:
        print(f"Error polling local hardware inputs: {hardware_err}")

def check_collisions():
    global score_p1, score_p2, shared_lives, frightened_timer, current_state, total_dots, gaming_data_cache
    dot_eaten = False
    
    if maze[player1_y][player1_x] == ".":
        maze[player1_y][player1_x] = " "; score_p1 += 10; dot_eaten = True; total_dots -= 1
    elif maze[player1_y][player1_x] == "O":
        maze[player1_y][player1_x] = " "; score_p1 += 50; dot_eaten = True; total_dots -= 1
        frightened_timer = FRIGHTENED_DURATION

    if maze[player2_y][player2_x] == ".":
        maze[player2_y][player2_x] = " "; score_p2 += 10; dot_eaten = True; total_dots -= 1
    elif maze[player2_y][player2_x] == "O":
        maze[player2_y][player2_x] = " "; score_p2 += 50; dot_eaten = True; total_dots -= 1
        frightened_timer = FRIGHTENED_DURATION

    if dot_eaten:
        rebuild_dot_surface()
        update_score_surfaces()
        
        if total_dots <= 0:
            if score_p1 != score_p2:
                winner = player1_name if score_p1 > score_p2 else player2_name
                
                final_input = capture_real_input_latency()
                final_transport = p2_rolling_latency_ms if 'p2_rolling_latency_ms' in globals() else 0.0

                session_manager.end_session(
                    highest_score=max(score_p1, score_p2), 
                    winner_name=winner,
                    real_input_latency=final_input,
                    real_transport_delay=final_transport
                )

            gaming_data_cache = None  
            current_state = "MAIN_MENU"
            return

    for ghost in ghosts:
        p1_hit = (player1_x == ghost["pos"][0] and player1_y == ghost["pos"][1])
        p2_hit = (player2_x == ghost["pos"][0] and player2_y == ghost["pos"][1])
        
        if p1_hit or p2_hit:
            if frightened_timer > 0:
                ghost["pos"] = list(ghost["start_pos"])
                ghost["prev_pos"] = None
                if p1_hit: score_p1 += 200
                if p2_hit: score_p2 += 200
                update_score_surfaces()
            else:
                shared_lives -= 1
                update_score_surfaces()
                if shared_lives <= 0:
                    if score_p1 != score_p2:
                        winner = player1_name if score_p1 > score_p2 else player2_name
                        session_manager.end_session(max(score_p1, score_p2), winner)
                    gaming_data_cache = None  
                    current_state = "MAIN_MENU"
                else:
                    reset_positions()
                break

def move_ghosts_ai():
    global ghost_timer, frightened_timer
    if frightened_timer > 0:
        frightened_timer -= 1

    ghost_timer += 1
    if ghost_timer >= 8:
        ghost_timer = 0
        for ghost in ghosts:
            valid_options = []
            gx, gy = ghost["pos"]
            for dx, dy in GHOST_MOVES:
                nx, ny = gx + dx, gy + dy
                if 0 <= ny < MAZE_ROWS and 0 <= nx < MAZE_COLS and maze[ny][nx] != "#":
                    valid_options.append([nx, ny])
            
            if valid_options:
                forward_options = [opt for opt in valid_options if opt != ghost["prev_pos"]]
                chosen = random.choice(forward_options) if forward_options else random.choice(valid_options)
                ghost["prev_pos"] = list(ghost["pos"])
                ghost["pos"] = chosen

def render_main_menu():
    screen.fill((0, 0, 0))
    screen.blit(title_surface, (title_x, 25))
    for index, (surf_normal, x_normal, surf_selected, x_selected, current_y) in enumerate(menu_cache):
        if index == selected_option: screen.blit(surf_selected, (x_selected, current_y))
        else: screen.blit(surf_normal, (x_normal, current_y))

def render_name_input():
    screen.fill((0, 0, 0))
    screen.blit(name_title_surf, (name_title_x, 15))
    
    p1_text = f"P1: {player1_name if player1_name else '_' * 8}" + (" (READY)" if p1_done else "")
    p2_text = f"P2: {player2_name if player2_name else '_' * 8}" + (" (READY)" if p2_done else "")
    p1_disp = font.render(p1_text, True, (255, 255, 0))
    p2_disp = font.render(p2_text, True, (0, 255, 0))
    

    screen.blit(p1_disp, (60, 45))
    screen.blit(p2_disp, (280, 45))
    
    cell_w, cell_h = 44, 34
    grid_start_x = (WIDTH - (7 * cell_w)) // 2
    grid_start_y = 90
    
    for r_idx, row in enumerate(CHAR_GRID):
        for c_idx, char in enumerate(row):
            if char == 'DONE' and c_idx > 0:
                continue
                
            x = grid_start_x + (c_idx * cell_w)
            y = grid_start_y + (r_idx * cell_h)
            w = cell_w * 7 if char == 'DONE' else cell_w
            
            is_p1_here = (p1_grid_pos[0] == r_idx) and (char == 'DONE' or p1_grid_pos[1] == c_idx) and not p1_done
            is_p2_here = (p2_grid_pos[0] == r_idx) and (char == 'DONE' or p2_grid_pos[1] == c_idx) and not p2_done
            
            if is_p1_here and is_p2_here:
                pygame.draw.rect(screen, (150, 150, 0), (x, y, w - 4, cell_h - 4), 2)
            elif is_p1_here:
                pygame.draw.rect(screen, (255, 255, 0), (x, y, w - 4, cell_h - 4), 1)
            elif is_p2_here:
                pygame.draw.rect(screen, (0, 255, 0), (x, y, w - 4, cell_h - 4), 1)
                
            if char == 'DONE':
                char_surf = cached_grid_surfaces[(4, 0)]
            else:
                char_surf = cached_grid_surfaces[(r_idx, c_idx)]
            screen.blit(char_surf, (x + (w // 2) - (char_surf.get_width() // 2), y + 10))

def render_lobby_check():
    screen.fill((0, 0, 0))
    screen.blit(lobby_title_surf, (lobby_title_x, 30))
    screen.blit(lobby_info_surf, (lobby_info_x, 75))
    
    if not p2_joined_via_can:
        text_x = (WIDTH // 2) - (lobby_p2_inactive_surf.get_width() // 2)
        screen.blit(lobby_p2_inactive_surf, (text_x, 140))
        
        circle_color = (240, 140, 20) if (int(time.time() * 2) % 2 == 0) else (40, 20, 0)
        pygame.draw.circle(screen, circle_color, (text_x - 18, 148), 5)
        screen.blit(lobby_prompt_surf, (lobby_prompt_x, 220))
    else:
        text_x = (WIDTH // 2) - (lobby_p2_active_surf.get_width() // 2)
        screen.blit(lobby_p2_active_surf, (text_x, 140))
        
        pygame.draw.circle(screen, (0, 255, 0), (text_x - 18, 148), 5)
        screen.blit(lobby_ready_surf, (lobby_ready_x, 220))

def render_gaming_data():
    global gaming_data_cache
    if gaming_data_cache is None:
        data = session_manager.load_gaming_data()
        live_layout = [
            ("High Score", f"{data['high_score_holder']} ({data['high_score']})"),
            ("Per-Session gaming duration (in Min)", ""),
            ("S1", f"{data['sessions'][0]} Min"),
            ("S2", f"{data['sessions'][1]} Min"),
            ("S3", f"{data['sessions'][2]} Min"),
            ("Overall time played", f"{data['overall_time']} Min"),
            ("Last time played", f"{data['last_time_played']} Min"),
            ("Input Latency (Pi 2)", f"{data['input_latency']} ms"),
            ("Transport delay (Pi 2)", f"{data['transport_delay']} ms"),
        ]
        gaming_data_cache = pygame.Surface((WIDTH, HEIGHT))
        gaming_data_cache.fill((0, 0, 0))
        gaming_data_cache.blit(gaming_title_surf, (gaming_title_x, 20))
        for index, (label, val) in enumerate(live_layout):
            y_pos = 60 + (index * 24) 
            if label in ("S1", "S2", "S3"): display_text, color = f"   {label} : {val}", (180, 180, 180)
            elif val == "": display_text, color = f"{label} :", (255, 255, 255)
            else: display_text, color = f"{label} : {val}", (255, 255, 255)
            gaming_data_cache.blit(font.render(display_text, True, color), (40, y_pos))
        gaming_data_cache = gaming_data_cache.convert()

    screen.blit(gaming_data_cache, (0, 0))

def render_board_stats():
    global board_stats_surface_cache, board_stats_frame_counter
    board_stats_frame_counter += 1

    if board_stats_surface_cache is None or board_stats_frame_counter >= 30:
        board_stats_frame_counter = 0
        p1_stats = board_stats.get_board_stats(comm_latency_ms=p2_rolling_latency_ms)
        
        p2_stats = get_p2_stats()
        
        dynamic_rows = [
            ("Parameter", "P1 (Local)", "P2 (Remote)"),
            ("CPU", p1_stats["CPU"], p2_stats["CPU"]),
            ("RAM", p1_stats["RAM"], p2_stats["RAM"]),
            ("Uptime", p1_stats["Uptime"], p2_stats["Uptime"]),
            ("Memory", p1_stats["Memory"], p2_stats["Memory"]),
            ("Software Version/ buildID", p1_stats["Software Version/ buildID"], p2_stats["Software Version/ buildID"]),
            ("Connection Status", p1_stats["Connection Status"], p2_stats["Connection Status"]),
            ("Temperature", p1_stats.get("Temperature", "N/A"), p2_stats["Temperature"]),
            ("Packet error count", p1_stats.get("Packet error count", "0"), p2_stats["Packet error count"]),
            ("Communication latency", p1_stats.get("Communication latency", "0ms"), p2_stats["Communication latency"]),
        ]
        surf = pygame.Surface((WIDTH, HEIGHT))
        surf.fill((0, 0, 0))
        surf.blit(board_title_surf, (board_title_x, 8))
        
        # Draw Border
        pygame.draw.rect(surf, (120, 120, 120), (table_x, table_y, table_w, row_h * len(dynamic_rows)), 1)
        

        for i in range(1, len(dynamic_rows)):
            pygame.draw.line(surf, (60, 60, 60), (table_x, table_y + (i * row_h)), (table_x + table_w, table_y + (i * row_h)), 1)
            
        # Vertical column lines
        pygame.draw.line(surf, (120, 120, 120), (table_x + col1_w, table_y), (table_x + col1_w, table_y + row_h * len(dynamic_rows)), 1)
        pygame.draw.line(surf, (120, 120, 120), (table_x + col1_w + col2_w, table_y), (table_x + col1_w + col2_w, table_y + row_h * len(dynamic_rows)), 1)
        
        for row_idx, row in enumerate(dynamic_rows):
            y = table_y + (row_idx * row_h)
            for col_idx, text in enumerate(row):
                color = (255, 215, 0) if row_idx == 0 else (230, 230, 230)
                cell_surf = table_font.render(text, True, color)
                if col_idx == 0:     
                    text_x = table_x + 5
                elif col_idx == 1:   
                    text_x = table_x + col1_w + (col2_w // 2) - (cell_surf.get_width() // 2) if row_idx == 0 else table_x + col1_w + 6
                else:                
                    text_x = table_x + col1_w + col2_w + (col3_w // 2) - (cell_surf.get_width() // 2) if row_idx == 0 else table_x + col1_w + col2_w + 6
                surf.blit(cell_surf, (text_x, y + 5))
        board_stats_surface_cache = surf.convert()

    screen.blit(board_stats_surface_cache, (0, 0))

def render_export_data():
    screen.fill((0, 0, 0))
    screen.blit(export_title_surf, (export_title_x, 20))
    screen.blit(instruction_surface, (instruction_x, 110))
    if export_status_msg:
        status_surf = font.render(export_status_msg, True, export_status_color)
        screen.blit(status_surf, ((WIDTH // 2) - (status_surf.get_width() // 2), 170))

def render_playing():
    move_ghosts_ai()
    check_collisions()
    
    if current_state != "PLAYING":
        return  

    screen.blit(maze_surface, (0, 0))
    screen.blit(dot_surface, (0, 0))
    screen.blit(hud_surface, (0, 0))

    for ghost in ghosts:
        gx = ghost["pos"][0] * TILE + TILE // 2 + MAZE_X_OFFSET
        gy = ghost["pos"][1] * TILE + TILE // 2 + MAZE_Y_OFFSET
        color = (0, 0, 255) if frightened_timer > 0 else ghost["color"]
        
        pygame.draw.circle(screen, color, (gx, gy), TILE // 2 - 1)
        pygame.draw.rect(screen, color, (ghost["pos"][0] * TILE + 1 + MAZE_X_OFFSET, gy, TILE - 2, TILE // 2))

    pygame.draw.circle(screen, (255, 255, 0), (player1_x * TILE + TILE // 2 + MAZE_X_OFFSET, player1_y * TILE + TILE // 2 + MAZE_Y_OFFSET), TILE // 2 - 2)
    pygame.draw.circle(screen, (0, 255, 0), (player2_x * TILE + TILE // 2 + MAZE_X_OFFSET, player2_y * TILE + TILE // 2 + MAZE_Y_OFFSET), TILE // 2 - 2)


# RUNTIME CORE GAME ENGINE LOOP

while True:
    if p1_nav_cooldown > 0: p1_nav_cooldown -= 1
    if p2_nav_cooldown > 0: p2_nav_cooldown -= 1
    if p1_btn_cooldown > 0: p1_btn_cooldown -= 1  # Decrement button cooldown frame counter
    if p1_move_cooldown > 0: p1_move_cooldown -= 1
    if p2_move_cooldown > 0: p2_move_cooldown -= 1

    poll_local_joystick_p1()

    if can_bus is not None:
        now = time.time()
        while True:
            msg = can_bus.recv(0.0) 
            if msg is None:
                break  
            
            if msg.arbitration_id == 0x100:
                try:
                    if p2_last_0x100_time is not None:
                        arrival_delta_ms = (now - p2_last_0x100_time) * 1000.0
                        packet_overhead = max(0.0, arrival_delta_ms - 50.0)
                        p2_rolling_latency_ms = (0.8 * p2_rolling_latency_ms) + (0.2 * packet_overhead)
                        slave_node_telemetry["Communication latency"] = f"{round(p2_rolling_latency_ms, 1)}ms"
                    p2_last_0x100_time = now

                    p2_x_raw, p2_y_raw, status_byte = struct.unpack('BBB', msg.data)
                    
                    p2_dx = -1 if p2_x_raw == 255 else p2_x_raw
                    p2_dy = -1 if p2_y_raw == 255 else p2_y_raw
                    
                    p2_joined_via_can = bool(status_byte & (1 << 0))
                    p2_btn_pressed = bool(status_byte & (1 << 1)) 

                    if current_state == "LOBBY_CHECK" and p2_joined_via_can:
                        if lobby_start_time is None:
                            lobby_start_time = time.time()
                    
                    elif current_state == "NAME_INPUT" and not p2_done:
                        if p2_nav_cooldown == 0 and (p2_dx != 0 or p2_dy != 0):
                            p2_grid_pos[0] = (p2_grid_pos[0] + p2_dy) % len(CHAR_GRID)
                            p2_grid_pos[1] = (p2_grid_pos[1] + p2_dx) % len(CHAR_GRID[0])
                            p2_nav_cooldown = COOLDOWN_FRAMES
                            
                        if p2_btn_pressed and p2_nav_cooldown == 0:
                            p2_char = CHAR_GRID[p2_grid_pos[0]][p2_grid_pos[1]]
                            if p2_char == 'DONE':
                                p2_done = True
                                if not player2_name: player2_name = "P2"
                                if p1_done:
                                    current_state = "LOBBY_CHECK"
                            elif p2_char == '<':
                                if player2_name:
                                    player2_name = player2_name[:-1]
                            elif len(player2_name) < 8:
                                player2_name += p2_char
                            p2_nav_cooldown = COOLDOWN_FRAMES
                    
                    elif current_state == "PLAYING" and p2_move_cooldown == 0:
                        moved = False
                        if p2_dx == -1 and player2_x > 0 and maze[player2_y][player2_x - 1] != "#": 
                            player2_x -= 1; moved = True
                        elif p2_dx == 1 and player2_x < MAZE_COLS - 1 and maze[player2_y][player2_x + 1] != "#": 
                            player2_x += 1; moved = True
                        elif p2_dy == -1 and player2_y > 0 and maze[player2_y - 1][player2_x] != "#": 
                            player2_y -= 1; moved = True
                        elif p2_dy == 1 and player2_y < MAZE_ROWS - 1 and maze[player2_y + 1][player2_x] != "#": 
                            player2_y += 1; moved = True
                        if moved:
                            p2_move_cooldown = MOVE_COOLDOWN_FRAMES
                            
                except Exception as parse_err:
                    print(f"Failed decoding 0x100 frame: {parse_err}")

            elif msg.arbitration_id == 0x200:
                try:
                    param_id = msg.data[0]
                    text_value = msg.data[1:].decode('utf-8').strip('\x00 ')
                    
                    metric_keys = {
                        1: "CPU", 
                        2: "RAM", 
                        3: "Memory", 
                        4: "Uptime", 
                        5: "Software Version/ buildID", 
                        6: "Connection Status",
                        7: "Temperature",
                        8: "Packet error count"
                    }
                    if param_id in metric_keys:
                        slave_node_telemetry[metric_keys[param_id]] = text_value
                        board_stats_surface_cache = None 
                except Exception as parse_err:
                    print(f"Failed decoding 0x200 telemetry frame: {parse_err}")

    if current_state == "LOBBY_CHECK" and lobby_start_time is not None:
        if time.time() - lobby_start_time >= 1.5:  
            lobby_start_time = None
            session_manager.start_session()  
            current_state = "PLAYING"

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        elif event.type == pygame.JOYBUTTONDOWN:
            execute_p1_button_action()

    if current_state == "MAIN_MENU":      render_main_menu()
    elif current_state == "NAME_INPUT":   render_name_input()
    elif current_state == "LOBBY_CHECK":  render_lobby_check()
    elif current_state == "GAMING_DATA":  render_gaming_data()
    elif current_state == "BOARD_STATS":  render_board_stats()
    elif current_state == "EXPORT_DATA":  render_export_data()
    elif current_state == "PLAYING":      render_playing()

    pygame.display.flip()
    clock.tick(20)