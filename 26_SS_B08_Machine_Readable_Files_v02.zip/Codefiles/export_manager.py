# export_manager.py
import os
import shutil
import getpass
import json
import datetime

SOURCE_FILE = "gaming_data.json"

# Cache target path location
_cached_usb_path = None


def _find_usb_drive():
    """Scans local media mounting namespaces for a valid write target directory."""
    username = getpass.getuser()  # Detects current OS user account automatically
    
    # Prioritizes dynamic user mounts, falling back to old 'pi' schemas if necessary
    for base in (f"/media/{username}/", "/media/pi/", "/media/"):
        if not os.path.exists(base):
            continue
        try:
            drives = [
                os.path.join(base, d)
                for d in os.listdir(base)
                if os.path.isdir(os.path.join(base, d))
            ]
            writable = [d for d in drives if os.access(d, os.W_OK)]
            if writable:
                return writable[0]
        except OSError:
            continue
    return None


def export_to_usb(board_stats_data):
    """Locates target mount block and writes out gaming data parameters along with board stats securely."""
    global _cached_usb_path

    if not os.path.exists(SOURCE_FILE):
        return False, "No gaming data found to export!"

    if _cached_usb_path is None or not os.path.exists(_cached_usb_path):
        _cached_usb_path = _find_usb_drive()

    if _cached_usb_path is None:
        return False, "No USB Drive Detected!"

    try:
        # Load the existing gaming data
        with open(SOURCE_FILE, "r") as f:
            gaming_data = json.load(f)

        # Structure the combined export payload
        combined_payload = {
            "gaming_data": gaming_data,
            "board_stats": board_stats_data
        }

        # Generate custom log filename matching: game_log_YYYY-MM-DD_HH-mm-ss.json
        timestamp_str = datetime.datetime.utcnow().strftime("%Y-%m-%d_%H-%M-%S")
        export_filename = f"game_log_{timestamp_str}.json"
        destination_path = os.path.join(_cached_usb_path, export_filename)

        # Write combined data out to the target storage medium
        with open(destination_path, "w") as f:
            json.dump(combined_payload, f, indent=4)

        # Force operating system file-system storage cache to flush out immediately to physical disc
        try:
            os.sync()
        except AttributeError:
            pass

        return True, f"Successfully exported to: {export_filename}"

    except Exception as e:
        _cached_usb_path = None  # Flush faulty directory reference cache on error
        return False, f"Export failed: {str(e)}"