# session_manager.py
import json
import os
import random
import time

DATA_FILE = "gaming_data.json"
_cache_invalidation_callback = None


def register_cache_invalidation_callback(fn):
    """Registers display cache cleaner function callback mapping to the main thread loop."""
    global _cache_invalidation_callback
    _cache_invalidation_callback = fn


def get_default_data():
    return {
        "high_score": 0,
        "high_score_holder": "No Record",
        "sessions": [0, 0, 0],  # Keeps last 3 sessions in minutes
        "overall_time": 0,      # Accumulated total time run metrics
        "last_time_played": 0,  
        "input_latency": 0.0,   
        "transport_delay": 0.0, 
    }


def load_gaming_data():
    if not os.path.exists(DATA_FILE):
        data = get_default_data()
        save_gaming_data(data)
        return data
    try:
        with open(DATA_FILE, "r") as f:
            return json.load(f)
    except Exception:
        return get_default_data()


def save_gaming_data(data):
    try:
        with open(DATA_FILE, "w") as f:
            json.dump(data, f, indent=4)
        if _cache_invalidation_callback:
            _cache_invalidation_callback()
        return True
    except Exception as e:
        print(f"Error executing storage state dump: {e}")
        return False


session_start_time = None


def start_session():
    global session_start_time
    session_start_time = time.time()


def end_session(highest_score, winner_name, real_input_latency=0.0, real_transport_delay=0.0):
    global session_start_time
    if session_start_time is None:
        print("Warning: end_session() called but no session was started. Data not saved.")
        return

    elapsed_seconds = time.time() - session_start_time
    duration_mins = round(elapsed_seconds / 60.0, 2)
    if duration_mins == 0:
        duration_mins = 0.1 

    data = load_gaming_data()

    # 1. Evaluate high-score achievements
    if highest_score > data["high_score"]:
        data["high_score"] = highest_score
        data["high_score_holder"] = winner_name

    # 2. Update sliding session storage array limits
    data["sessions"].insert(0, duration_mins)
    data["sessions"] = data["sessions"][:3]

    # 3. Compile timeline telemetry constants
    data["overall_time"] = round(data["overall_time"] + duration_mins, 2)
    data["last_time_played"] = duration_mins

    # 4. Save ACTUAL collected variables passed into the function
    data["input_latency"] = round(real_input_latency, 2)
    data["transport_delay"] = round(real_transport_delay, 2)

    save_gaming_data(data)
    session_start_time = None